<html>
<head>
    <title> Web Programming </title>
</head>
<body>

<?php
    echo "<h3>Assalamualaikum</h3>";
    echo "Tarikh hari ini: ".
        date("d M Y");
?>
</body>
</html>