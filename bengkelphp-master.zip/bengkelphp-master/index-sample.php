<?php
//makesure to save-as this file to index.php
header ("location: login.php");
?>